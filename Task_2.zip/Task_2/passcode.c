#include "passcode.h"			//header contains function prototypes and variables decelerations
#include "main.h"				//main header for low-level driver access

//global declaration of array str[] and variables
uint16_t str[] = {1020, 5020, 6030, 8520, 4563, 7412, 9685, 3259, 4123, 7860};
uint16_t pass, temp, temp1;

// FUNCTION      : void led_ON()
// DESCRIPTION   : function used to set Red at PB.7 LED when passcode is matched with elements in the array
// PARAMETERS    : no parameters passed into function
// RETURNS       : returns void
void red_led_ON(){
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);
	HAL_Delay(500);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);
	HAL_Delay(500);
}

// FUNCTION      : void green_led_ON()
// DESCRIPTION   : function used to set Green LED at PB.0 when passcode is matched with elements in the array
// PARAMETERS    : no parameters passed into function
// RETURNS       : returns void
void green_led_ON(){
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET);
	HAL_Delay(500);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);
	HAL_Delay(500);
}

// FUNCTION      : password_check()
// DESCRIPTION   : function used to;
//					1. takes input passcode from user via VCP
//					2. check if passcode matches any of the codes included in the array
//					3. calls led functions
//					4. calls audio beep functions
// PARAMETERS    : no parameters passed into function
// RETURNS       : returns void
void password_check()
{
	printf("Enter password : \n\r");
	scanf("%d",&pass);
	temp = pass;
	printf("Entered password is : %d\n\r",pass);
	for (uint16_t i=0; i<10;i++)					//for-loop to compare each element of array with input
	{
		if (temp == str[i])							//if condition to take matching element of array in variable temp1
		{
			temp1 = str[i];
		}
	}
	if (temp1 == temp)								//if condition to if variable temp is equal variable temp1
	{
		printf("Access Granted\n\r",temp);
		green_led_ON();		//call to led_ON() function
		acces_grant_beep();
	}
	else
	{
		printf("Access Denied\n\r",temp);
		red_led_ON();
		acces_denied_beep();
	}
	temp = 0;										//clearing temp and temp1 variables
	temp1 = 0;
	HAL_Delay(1000);								//delay of 1000ms/1sec
}
