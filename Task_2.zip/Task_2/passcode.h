/***Header files including all function prototypes from passcode.c***/
void red_led_ON();
void green_led_ON();
void password_check();
