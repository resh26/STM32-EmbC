//inclusion of all header files
#include "main.h"
#include "adc.h"
#include "ssd1331.h"

//initialization of extern variables
__IO float temp_celicus = 0;
__IO float analog_ip = 0;
__IO int16_t uhADCxConvertedValue = 0;
__IO uint16_t decimal = 0;

// FUNCTION      : void adc_data()
// DESCRIPTION   : function used to calculate temperature value from analog input pin also it has if-else
//				   loop for different temperatures to glow RGB Led accordingly
// PARAMETERS    : no parameters passed into function
// RETURNS       : returns void

void adc_data(int16_t temp_analog_val)
{
	//calculation to convert analog values into decimal once
	analog_ip = (temp_analog_val * Vref) / bit;
	temp_celicus = (analog_ip - 0.5) / 0.01;
	decimal = (temp_celicus - (int) temp_celicus) * 10;
	//function call to display temperature on OLED display
	LCD_data_display();
	//a temp_var to hold current decimal temperature value
	uint16_t temp_var = temp_celicus;
	//conditional if-else loop to glow RGB Led at various temperature range
	if (temp_var <= -15){
		Led_RGB(1000, 1000, 1000);											//LED : White
		ssd1331_display_string(20, 25, "FREEZING", FONT_1206, WHITE);		//String to display on OLED
	} else if (temp_var >= -15.1 && temp_var <= 5) {
		Led_RGB(0, 1000, 0);												//LED : Blue
		ssd1331_display_string(30, 25, "CHILLING", FONT_1206, GREEN);
	} else if (temp_var >= 5.1 && temp_var <= 15) {
		Led_RGB(1000, 0, 1000);												//LED : Yellow
		ssd1331_display_string(60, 25, "COLD", FONT_1206, YELLOW);
	} else if (temp_var >= 15.1 && temp_var <= 25) {
		Led_RGB(1000, 0, 700);												//LED : Orange
		ssd1331_display_string(20, 25, "AVERAGE TEMP", FONT_1206, CYAN);
	} else if (temp_var > 25){
		Led_RGB(1000, 0, 0);												//LED : Red
		ssd1331_display_string(60, 25, "HOT", FONT_1206, RED);
	}else{
		Led_RGB(0, 0, 0);
		ssd1331_display_string(0, 25, "INVALID TEMP", FONT_1206, RED);
	}
}

// FUNCTION      : void Led_RGB()
// DESCRIPTION   : function used to set values in registers in Timmmer1 to gain different
//				   colors from RGB Led
// PARAMETERS    : 3 uint16_t values for red, blue and green color respectively
// RETURNS       : returns void

void Led_RGB(uint16_t red, uint16_t blue, uint16_t green)
{
	TIM1->CCR1 = red;
	TIM1->CCR2 = blue;
	TIM1->CCR3 = green;
}

// FUNCTION      : void LCD_data_display()
// DESCRIPTION   : function used to display temperature in degree ⁰C and its settings
// PARAMETERS    : no parameters passed into function
// RETURNS       : returns void

void LCD_data_display()
{
	//if-else loop to display +ve and -ve temperatures respectively
	if (temp_celicus < 0){
		ssd1331_display_char(55, 15, '-', FONT_1206, GREEN);
		ssd1331_display_num(60, 15, temp_celicus, 2, FONT_1206, GREEN);
		ssd1331_display_char(72, 15, '.', FONT_1206, GREEN);
		ssd1331_display_num(78, 15, decimal, 1, FONT_1206, GREEN);
		ssd1331_draw_circle(85, 15, 1, GREEN);
		ssd1331_display_char(90, 15, 'C', FONT_1206, GREEN);
		HAL_Delay(1000);
	}else{
		ssd1331_display_num(60, 15, temp_celicus, 2, FONT_1206, GREEN);
		ssd1331_display_char(72, 15, '.', FONT_1206, GREEN);
		ssd1331_display_num(78, 15, decimal, 1, FONT_1206, GREEN);
		ssd1331_draw_circle(85, 15, 1, GREEN);
		ssd1331_display_char(90, 15, 'C', FONT_1206, GREEN);
		HAL_Delay(1000);
	}
}
