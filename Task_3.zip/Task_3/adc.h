/*******************************************************************************
  * File Name          : adc.h
  * Description        : file has all functions from adc.c and extern variables and macros
  * Author:            : Reshma Rathod
  * Date:              :  16/11/2022
/  ******************************************************************************
  */

#ifndef SRC_ADC_H_
#define SRC_ADC_H_

void adc_data(int16_t);
void Led_RGB(uint16_t, uint16_t, uint16_t);
void LCD_data_display();

extern __IO float temp_celicus;
extern __IO float analog_ip;
extern __IO uint16_t decimal;
extern volatile __IO int16_t uhADCxConvertedValue;
#define Vref 3.3
#define bit 4095

#endif /* SRC_ADC_H_ */
