/*
 * DebitMachine.c
 * Created on: 30-Nov-2022
 *  Author: Reshma Rathod
 */
#include "main.h"
#include <unistd.h>
#include <stdio.h>
#include "debounce.h"
#include "ssd1331.h"
#include "fonts.h"
#include "DebitMachine.h"

static const int16_t chequingPbPin; //setting the pin assigned to each pb
static const int16_t savingsPbPin;		//don't use pin 2 as it's connected
static const int16_t okPbPin;		//to VCP TX
static const int16_t cancelPbPin;

// FUNCTION      : displayWelcome()
// DESCRIPTION   : clears the OLED display and displays
//                 Welcome on line 1 of the display
// PARAMETERS    : None
// RETURNS       : nothing
void displayWelcome(void) {
	char stringBuffer[35] = { 0 };
	ssd1331_clear_screen(BLACK);
	snprintf(stringBuffer, 35, " ASSIGNMENT 4:DEBIT MACHINE");
	ssd1331_display_string(0, 22, stringBuffer, FONT_1206, WHITE);
	snprintf(stringBuffer, 35, "WELCOME...");
	ssd1331_display_string(20, 50, stringBuffer, FONT_1206, WHITE);
}

// FUNCTION      : displayAmount()
// DESCRIPTION   : clears the OLED display and displays
//                 the $amount received on line 1 of the display
// PARAMETERS    : float - amount to display
// RETURNS       : nothing
void displayAmount(float amount) {
	ssd1331_clear_screen(BLACK);
	char stringBuffer[20] = { 0 };
	snprintf(stringBuffer, 20, "$%.2f", amount);
	ssd1331_display_string(0, 0, stringBuffer, FONT_1206, WHITE);
}

// FUNCTION      : checkIfAmountRecd()
// DESCRIPTION   :
// PARAMETERS    : none
// RETURNS       : float, the amount in $ to be debited
float checkIfAmountRecd() {
	char stringBuffer[13] = { 0 };
	ssd1331_clear_screen(BLACK);
	snprintf(stringBuffer, 15, "Enter Amount:");
	ssd1331_display_string(0, 0, stringBuffer, FONT_1206, WHITE);
	float debitAmount = 0;
	//printf("waiting for debitAmount to be received on serial port\r\n");
	int16_t result = 0;
	result = scanf("%f", &debitAmount);
	if (result == 0)		//then somehow non-float chars were entered
	{						//and nothing was assigned to %f
		fpurge(STDIN_FILENO); //clear the last erroneous char(s) from the input stream
	}
	return debitAmount;
}

// FUNCTION      : checkOkOrCancel()
// DESCRIPTION   : Checks whether the OK or Cancel
//                 button has been pressed.
// PARAMETERS    : none
// RETURNS       : int8_t, 3 if cancel pressed, 4 if ok
//                 ok pressed. 0 returned if neither
//                 has pressed.
enum pushButton checkOkOrCancel(void) {
	if (deBounceReadPin(cancelPbPin, 'A', 10) == 0) {
		//then the cancel pushbutton has been pressed
		return cancel;
	} else if (deBounceReadPin(okPbPin, 'A', 10) == 0) {
		//then ok pressed
		return ok;
	}
	return none; //as ok or cancel was not pressed.
}

// FUNCTION      : displayOkOrCancel()
// DESCRIPTION   : displays "OK or Cancel?" on line 2 of OLED
// PARAMETERS    : none
// RETURNS       : nothing.
void displayOkCancel(void) {
	char stringBuffer[16] = { 0 };
	snprintf(stringBuffer, 16, "OK or Cancel?");
	ssd1331_display_string(0, 10, stringBuffer, FONT_1206, WHITE);
}

// FUNCTION      : checkchequingOrSavings()
// DESCRIPTION   : Checks whether the Chequing or Saving
//                 button has been pressed.
// PARAMETERS    : none
// RETURNS       : int8_t, 3 if cancel pressed,  0 if
//                 cgequing is pressed, 1 if savings is pressed . 0 returned if neither
//                 has pressed.
enum pushButton checkchequingOrSavings(void) {
	if (deBounceReadPin(chequingPbPin, 'A', 10) == 0) {
		                              //then the cancel pushbutton has been pressed
		return chequing;
	} else if (deBounceReadPin(savingsPbPin, 'A', 10) == 0) {
		                              //then savings pressed
		return savings;
	} else if (deBounceReadPin(cancelPbPin, 'A', 10) == 0) {
				                      //then the cancel pushbutton has been pressed
		return cancel;
	}
	return none; //as ok or cancel was not pressed.
}

// FUNCTION      : displaychequeingOrsaving()
// DESCRIPTION   : displays "Cheq or saving?" on line 2 of OLED
// PARAMETERS    : none
// RETURNS       : nothing.
void displayChequingorSaving(void) {
	ssd1331_clear_screen(BLACK);
	char stringBuffer[25] = { 0 };
	snprintf(stringBuffer, 20, "chequing or saving?");
	ssd1331_display_string(0, 10, stringBuffer, FONT_1206, WHITE);

}

// FUNCTION      : displayChequeing()
// DESCRIPTION   : displays "Chequing" on line 2 of OLED
// PARAMETERS    : none
// RETURNS       : nothing.
void displayChequing(void) {
	char stringBuffer[10] = { 0 };
	snprintf(stringBuffer, 10, "Chequing");
	ssd1331_display_string(0, 10, "                    ", FONT_1206, WHITE);
	ssd1331_display_string(0, 20, stringBuffer, FONT_1206, WHITE);
}

// FUNCTION      : displaySavings()
// DESCRIPTION   : displays "saving" on OLED
// PARAMETERS    : none
// RETURNS       : nothing.
void displaySavings(void) {
	char stringBuffer[10] = { 0 };
	snprintf(stringBuffer, 10, "Savings");
	ssd1331_display_string(0, 10, "                   ", FONT_1206, WHITE);
	ssd1331_display_string(0, 20, stringBuffer, FONT_1206, WHITE);
}

// FUNCTION      : displayTransactioncancelled()
// DESCRIPTION   : clears the OLED display and displays
//                 Welcome on line 1 of the display
// PARAMETERS    : None
// RETURNS       : nothing
void displayTransactioncancelled(void) {
	char stringBuffer[26] = { 0 };
	snprintf(stringBuffer, 26, "Transaction     cancelled");
	ssd1331_display_string(0, 10, "                    ", FONT_1206, WHITE);
	ssd1331_display_string(0, 20, stringBuffer, FONT_1206, WHITE);
}

// FUNCTION      : enterPin()
// DESCRIPTION   : displays Pin entered on OLED
// PARAMETERS    : None
// RETURNS       : nothing
void EnterPin(void) {
	char stringBuffer[10] = { 0 };
	ssd1331_clear_screen(BLACK);
	snprintf(stringBuffer, 10, "Enter Pin");
	ssd1331_display_string(0, 20, stringBuffer, FONT_1206, WHITE);
}

// FUNCTION      : DisplayTranscationStatus()
// DESCRIPTION   : displays "Display transation successful" on OLED
// PARAMETERS    : none
// RETURNS       : nothing.
void DisplayTranscationStatus(void) {
	char stringBuffer[100] = { 0 };
	ssd1331_clear_screen(BLACK);
	snprintf(stringBuffer, 22, "Connecting with Bank");
	ssd1331_display_string(0, 0, stringBuffer, FONT_1206, WHITE);
	snprintf(stringBuffer, 25, "Transaction Sucessful");
	ssd1331_display_string(30, 20, stringBuffer, FONT_1206, WHITE);
}

// FUNCTION      : TransactionEnd()
// DESCRIPTION   : represents transaction end
// PARAMETERS    : none
// RETURNS       : nothing.
void TransactionEnd(void){
	ssd1331_clear_screen(BLACK);
	char stringBuffer[15] = { 0 };
	snprintf(stringBuffer, 15, "Thank You...");
	ssd1331_display_string(0, 0, stringBuffer, FONT_1206, WHITE);
}

// FUNCTION      : PinStatus(int)
// DESCRIPTION   : displays pin valid status on OLED
// PARAMETERS    : none
// RETURNS       : nothing.
void PinStatus(int pin_flag){
	char stringBuffer[25] = { 0 };
	if (pin_flag == 1)
	{
		ssd1331_clear_screen(BLACK);
		snprintf(stringBuffer, 25, "PIN ACCEPTED");
		ssd1331_display_string(0, 20, stringBuffer, FONT_1206, WHITE);
	}
	else
	{
		ssd1331_clear_screen(BLACK);
		snprintf(stringBuffer, 15, "INCORRECT PIN");
		ssd1331_display_string(0, 20, stringBuffer, FONT_1206, WHITE);
	}
}
