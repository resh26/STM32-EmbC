/*
 * DebitMachine.h
 * Created on: 30-Nov-2022
 *  Author: Reshma Rathod
 */

#ifndef SRC_DEBITMACHINE_H_
#define SRC_DEBITMACHINE_H_

void displayWelcome(void);
void displayAmount(float amount);
float checkIfAmountRecd();
enum pushButton checkOkOrCancel(void);
void displayOkCancel(void) ;
enum pushButton checkchequingOrSavings(void);
void displayChequingorSaving(void);
void displayChequing(void);
void displaySavings(void);
void displayTransactioncancelled(void);
void EnterPin(void);
void DisplayTranscationStatus(void) ;
void TransactionEnd(void);
void Welcome(void);
void PinStatus(int);

static const int16_t chequingPbPin = 0;
static const int16_t savingsPbPin = 1;
static const int16_t okPbPin = 4;
static const int16_t cancelPbPin = 3;

enum pushButton {
	none, chequing, savings, ok, cancel
};

extern int pin ;

#endif /* SRC_DEBITMACHINE_H_ */
