/* gps.c
 * Created on: 13-Dec-2022
 * Author: Reshma Rathod
 */

#include "main.h"
#include "gps.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

// FUNCTION      : UTC_Time_data
// DESCRIPTION   : Loop used to extract specific data
//				 : such as hours, minute and seconds
//				 : from string received
// PARAMETERS    : int val and char pointer
// RETURNS       : nothing
void UTC_Time_data(int32_t myVal,char *UTCTime) {

	int16_t digit = 0;
	while (myVal > 0) {
		myVal = myVal / 10;
		digit++;
	}
	myVal = atoi(UTCTime);

	int16_t count = digit;
	char arr[count];
	while (count--) {
		arr[count] = myVal % 10;
		myVal /= 10;
	}
	double decimal = atof(UTCTime);
	int16_t second = (decimal - (int)decimal)*100;

	if (digit == 5) {
		printf("Hour: %d hr \r\n", arr[0]);
		printf("Minute: %d min \r\n", (arr[1] * 10) + (arr[2]));
		printf("Second: %d.%d sec \r\n", (arr[3] * 10) + (arr[4]),second);
	}

	else if (digit == 6) {
		printf("Hour: %d hr \r\n", (arr[0] * 10) + (arr[1]));
		printf("Minute: %d min \r\n", (arr[1] * 10) + (arr[2]));
		printf("Second: %d sec \r\n", (arr[3] * 10) + (arr[4]));
	}

	else{
		printf("Time digits are invalid\r\n");
	}
	printf("\n");

}

// FUNCTION      : Latitude_data
// DESCRIPTION   : Loop used to extract specific data
//				 : of latitude in degree and minutes
// PARAMETERS    : int val and char pointer
// RETURNS       : nothing
void Latitude_data(int32_t lat,char *Latitude) {
	    int16_t digit = 0;
		while (lat > 0) {
			lat = lat / 10;
			digit++;
		}
		lat = atoi(Latitude);

		int16_t count = digit;
		char arr[count];
		while (count--) {
			arr[count] = lat % 10;
			lat /= 10;
		}
		double decimal = atof(Latitude);
		int16_t second = (decimal - (int)decimal)*10000;

		if (digit == 4) {
			printf("Degrees: %d degrees \r\n", (arr[0] * 10) + (arr[1]));
			printf("Minutes: %d minutes \r\n", (arr[2] * 10) + (arr[3]));
			printf("Decimal Degree: %d decimal degree \r\n",second);
		}

		else{
			printf("Latitude data are invalid\r\n");
		}
		printf("\n");
}

// FUNCTION      : Longitude_data
// DESCRIPTION   : Loop used to extract specific data
//				 : of longitude in degree and minutes
// PARAMETERS    : int val and char pointer
// RETURNS       : nothing
void Longitude_data(int32_t log,char *Longitude) {
	    int16_t digit = 0;
		while (log > 0) {
			log = log / 10;
			digit++;
		}
		log = atoi(Longitude);

		int16_t count = digit;
		char arr[count];
		while (count--) {
			arr[count] = log % 10;
			log /= 10;
		}
		double decimal = atof(Longitude);
		int16_t second = (decimal - (int)decimal)*10000;

		if (digit == 4) {
			printf("Degrees: %d degrees \r\n", (arr[0] * 10) + (arr[1]));
			printf("Minutes: %d minutes \r\n", (arr[2] * 10) + (arr[3]));
			printf("Decimal Degree: %d decimal degree \r\n",second);
		}

		else{
			printf("Latitude data are invalid\r\n");
		}
		printf("\n");
}
