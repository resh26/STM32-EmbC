/* gps.h
 * Created on: 13-Dec-2022
 * Author: Reshma Rathod
 */

#ifndef SRC_GPS_H_
#define SRC_GPS_H_

void UTC_Time_data(int32_t ,char*);
void Latitude_data(int32_t ,char*);
void Longitude_data(int32_t ,char*);


#endif /* SRC_GPS_H_ */
