/* adc.c
 * Created on: Dec 14, 2022
 * Author: Reshma Rathod
 */
#include "main.h"
#include "adc.h"
#include <stdio.h>

// FUNCTION      : adc_led
// DESCRIPTION   : checks various range of adc inputs and display LED3 on board accordingly
// PARAMETERS    : uint16 adc_in
// RETURNS       : nothing
void adc_led(uint16_t adc_in)
{
	switch (adc_in)
			{
	case 0x222 ... 0x888:
		HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_3);
		HAL_Delay(5);
		HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_3);
		HAL_Delay(2000);
		printf("ADC value at lower range: %X\r\n", adc_in);
		break;
	case 0xAAA ... 0xFFF:
		HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_3);
		HAL_Delay(2000);
		HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_3);
		HAL_Delay(2000);
		printf("ADC value at higher range: %X\r\n", adc_in);
		break;
	case 0x899 ... 0x999:
		HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_3);
		HAL_Delay(1000);
		HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_3);
		HAL_Delay(1000);
		printf("ADC value at mid range: %X\r\n", adc_in);
		break;
	default:
		HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_3);
		HAL_Delay(3);
		HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_3);
		HAL_Delay(3);
		printf("ADC value for default range: %X\r\n", adc_in);
		break;
	}
}
