/* adc.h
 * Created on: Dec 14, 2022
 * Author: Reshma Rathod
 */

#ifndef SRC_ADC_H_
#define SRC_ADC_H_

void adc_led(uint16_t );

#endif /* SRC_ADC_H_ */
